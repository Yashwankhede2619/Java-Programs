class WideningInt
{
	public static void main(String [] args)
	{
	
	int b = 100;
	long l = b;
	float f = b;
	double d = b;

	System.out.println(" Int is : "+b);
	System.out.println(" Long is : "+l);
	System.out.println(" Float is : "+f);
	System.out.println(" double is : "+d);
	}
}