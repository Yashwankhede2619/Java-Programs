class Program1
{
	public static void main(String [] args)
	{
	 System.out.print("My name is Abhishek raju pulate.");
	 System.out.print("I am currently persuing my bachelors degree in computor science,");
	 System.out.println("from babasaheb naik college of engineering pusad.");
	 System.out.println("i am intereseted in the software technologies and eager to learn and implement technologies for development");
	 System.out.print("I believe my strengths lie in problem-solving, analytical thinking, and my ability to learn new tools and technologies quickly,");
	 System.out.println("my weaknes is being too kind sometimes.");
	 System.out.print("And my short term goal is to be well profiecient in java full stack and get a good job,");
	 System.out.println("also my long term goal is to be a master in java full stack and ai technologies to create softwares with ai assistant for efficiency and time saving.");
	}
}

