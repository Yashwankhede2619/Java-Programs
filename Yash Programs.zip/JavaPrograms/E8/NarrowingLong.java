class NarrowingLong
{
	public static void main(String [] args)
	{
		long d =123456789;
		int i =(int) d;
		char c =(char) d;
		short s =(short) d;
		byte b =(byte) d;
		System.out.println(d);
		System.out.println(i);
		System.out.println(c);
		System.out.println(s);
		System.out.println(b);
	}
}
