class WideningShort
{
	public static void main(String [] args)
	{
	short b = 100;
	//char ch = b;  //CTE - Lossy conversion from byte to char
	int i = b;
	long l = b;
	float f = b;
	double d = b;
	System.out.println(" Short is : "+b);
	//System.out.println(" Char is : "+ch);
	System.out.println(" Int is : "+i);
	System.out.println(" Long is : "+l);
	System.out.println(" Float is : "+f);
	System.out.println(" double is : "+d);
	}
}