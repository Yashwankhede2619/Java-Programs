class CompoundOpNarrowing
{
	public static void main(String [] args)
	{
		int num1 = 100;
		float num2 = 200.65463f;
		num1 += num2;
		System.out.println(num1);
	}
}