class NarrowingShort
{
	public static void main(String [] args)
	{
		short d = 32000;
		byte b =(byte) d;
		System.out.println(d);
		System.out.println(b);
	}
}
