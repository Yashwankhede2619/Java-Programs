import java.util.Scanner;
class largeSmallNum
{
	public static void main(String [] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter num 1 :");
		int num1 = sc.nextInt();
		System.out.print("Enter the num 2 :");
		int num2 = sc.nextInt();
		System.out.print("Enter the num 3 :");
		int num3 = sc.nextInt();
		System.out.println(
			(num1>num2&&num1>num3)?(num1+" Is the largest number"):
			((num2>num1&&num2>num3)?(num2+" Is the largest number"):(num3+" Is the largest number")));
	}
}
