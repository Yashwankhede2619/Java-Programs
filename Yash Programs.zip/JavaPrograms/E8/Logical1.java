class Logical1
{
	public static void main(String [] args)
	{
		System.out.println(true&&true);                 //true
		System.out.println(true||true);					//true
		System.out.println(true&&false);				//false
		System.out.println((!true)&&true);				//false
		System.out.println(0%2==0||1%2==1);				//true
		System.out.println(4>6&&false);					//false
		System.out.println(!false||!true);				//true
		System.out.println('a'=='A'||false==false);		//true
		System.out.println('a'/'b'==0||'1'==1);			//true
	}
}