import java.util.Scanner;
class Pattern
{
	public static void main(String [] args)
	{
	 Scanner sc = new Scanner(System.in);
	 System.out.print("Enter the length of triangle : ");
	 int Length = sc.nextInt();
	 for(int i=0; i<=Length ; i++)
	 	{
	 		for(int j = i ; j<Length; j++)
	 		{
		 	System.out.print("*");
			}
		 System.out.println();
		}
	}
}