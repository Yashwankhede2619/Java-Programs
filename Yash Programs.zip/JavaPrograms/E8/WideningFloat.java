class WideningFloat
{
	public static void main(String [] args)
	{
	
	float b = 100f;
	double d = b;

	System.out.println(" Float is : "+b);
	System.out.println(" double is : "+d);
	}
}