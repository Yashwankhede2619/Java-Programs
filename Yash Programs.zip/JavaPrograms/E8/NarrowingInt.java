class NarrowingInt
{
	public static void main(String [] args)
	{
		int d =264;
		char c =(char) d;
		short s =(short) d;
		byte b =(byte) d;
		System.out.println(d);
		System.out.println(c);
		System.out.println(s);
		System.out.println(b);
	}
}
