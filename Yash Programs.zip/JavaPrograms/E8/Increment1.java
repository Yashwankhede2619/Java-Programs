class Increment1
{
	public static void main(String [] args)
	{
		int a=5,b=7,c=3,d;
		a=b++ - --c;
		d=++c + b--;
		c=a++ + --b + ++d;
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}
}