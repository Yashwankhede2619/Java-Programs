import java.util.Scanner;
class Operators 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Modulus is : ");
		boolean a = true ;
		boolean b = false
			;
		boolean c = a % b;
		System.out.println(c);
	}
}
