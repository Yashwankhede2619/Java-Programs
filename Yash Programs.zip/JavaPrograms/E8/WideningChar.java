class WideningChar
{
	public static void main(String [] args)
	{
	
	char b = 100;  //CTE - Lossy conversion from byte to char
	int i = b;
	long l = b;
	float f = b;
	double d = b;

	System.out.println(" Char is : "+b);
	System.out.println(" Int is : "+i);
	System.out.println(" Long is : "+l);
	System.out.println(" Float is : "+f);
	System.out.println(" double is : "+d);
	}
}