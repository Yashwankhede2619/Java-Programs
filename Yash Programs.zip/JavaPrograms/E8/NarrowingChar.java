class NarrowingChar
{
	public static void main(String [] args)
	{
		char d ='v';
		short s =(short) d;
		byte b =(byte) d;
		System.out.println(d);
		System.out.println(s);
		System.out.println(b);
	}
}
