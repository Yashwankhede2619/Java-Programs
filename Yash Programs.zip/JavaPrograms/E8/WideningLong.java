class WideningLong
{
	public static void main(String [] args)
	{
	
	long b = 100;
	float f = b;
	double d = b;

	System.out.println(" Long is : "+b);
	System.out.println(" Float is : "+f);
	System.out.println(" double is : "+d);
	}
}