class DelCode1
{
	public static void main(String [] args)
	{
		int students = 3; 
		int count = 5;
		System.out.println((count%students)+1);
	}
}